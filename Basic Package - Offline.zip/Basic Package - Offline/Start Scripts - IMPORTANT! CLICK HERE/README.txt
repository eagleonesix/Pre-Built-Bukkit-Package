Choose a start script from the folders, 
and copy it into your root minecraft folder directory (the directory that contains your plugins, and world folders. 
Simple. :)

Choose a start script depending on your platform, and Java version.